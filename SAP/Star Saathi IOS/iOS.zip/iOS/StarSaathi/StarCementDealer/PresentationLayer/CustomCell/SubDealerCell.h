//
//  SubDealerCell.h
//  StarCementDealer
//
//  Created by Coral  on 05/07/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubDealerCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblSubDealer;

@end
