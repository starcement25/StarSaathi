//
//  SchemeCell.h
//  StarCementDealer
//
//  Created by Apple on 11/04/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SchemeCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgViewThumbnail;
@property (weak, nonatomic) IBOutlet UILabel *lblScheme;
@end
