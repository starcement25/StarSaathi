//
//  SliderCell.h
//  StarCementDealer
//
//  Created by Coral  on 07/07/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SliderCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgViewSlider;
@end
