//
//  OrderEnquiryCell.h
//  StarCementDealer
//
//  Created by Forcepower Infotech Pvt Ltd on 06/12/24.
//  Copyright © 2024 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderEnquiryCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblProdName;
@property (weak, nonatomic) IBOutlet UILabel *lblQtyBags;
@property (weak, nonatomic) IBOutlet UILabel *lblDateAndTime;
@property (weak, nonatomic) IBOutlet UILabel *lblRssdName;
@property (weak, nonatomic) IBOutlet UILabel *lblDateOfLifting;
@property (weak, nonatomic) IBOutlet UILabel *lblRemarks;
@end

NS_ASSUME_NONNULL_END
