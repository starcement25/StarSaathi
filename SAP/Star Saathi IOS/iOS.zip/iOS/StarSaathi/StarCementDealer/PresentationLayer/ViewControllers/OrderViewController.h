//
//  OrderViewController.h
//  StarCementDealer
//
//  Created by Coral  on 05/07/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderViewController : UIViewController
@property(strong, nonatomic)NSMutableArray *arrProdList;
@end
