//
//  NotificationViewController.m
//  StarCementDealer
//
//  Created by Apple on 06/02/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import "NotificationViewController.h"
#import "NotificationCell.h"
#import "NotificationBO.h"
#import <UIImageView+AFNetworking.h>
#import "NotificationDetailViewController.h"
#import "WebViewController.h"

@interface NotificationViewController ()<UITableViewDelegate, UITableViewDataSource>{
    __weak IBOutlet UITableView *tblViewNotification;
    NSMutableArray *arrNotification;
    
}

@end

@implementation NotificationViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self designView];
    [self loadData];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //[self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Initialization Method

-(void)designView{
    [tblViewNotification registerNib:[UINib nibWithNibName:@"NotificationCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    tblViewNotification.tableFooterView = [UIView new];
}

-(void)loadData{
    
    arrNotification = [[NSMutableArray alloc]init];
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
    FMDatabase *db = [FMDatabase databaseWithPath:path];
    if ([db open]) {
        BOOL success =  [db executeUpdate:@"DELETE FROM notification"];
        if (success) {
            [self getNotification:@""];
        }
        [db close];
    }
}

#pragma mark - UITableView Delegate and Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return arrNotification.count;
}

- (NotificationCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"cell";
    NotificationCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    NotificationBO *NBO = arrNotification[indexPath.row];
    cell.lblTitle.text = NBO.strNotificationTitle;
    cell.lblDescription.text = NBO.strNotificationMsg;
    
    if (![NBO.strNotificationType isEqualToString:@"PDF"]) {
        [cell.imgViewNotification setImageWithURL:[NSURL URLWithString:NBO.strNotificationImgLink] placeholderImage:[UIImage imageNamed:@"user_placeholder"]];
    }else{
        cell.imgViewNotification.image = [UIImage imageNamed:@""];
    }
    
    cell.backgroundColor = ([NBO.strStatus isEqualToString:@"READ"]) ? UIColorFromRGB(0xDBDBDB) : [UIColor whiteColor];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{    
    return UITableViewAutomaticDimension;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NotificationBO *nbo = arrNotification[indexPath.row];
    NSString *strNotiStatus = [self getStatusWithNotiId:nbo.strNotificationId];
    if ([strNotiStatus isEqualToString:@"UNREAD"]) {
        [self updateReadStatusWithNotificationId:nbo.strNotificationId];
    }
    
    if ([nbo.strNotificationType isEqualToString:@"PDF"]) {
        [self performSegueWithIdentifier:@"notificationListToWebview" sender:self];
    }else{
        [self performSegueWithIdentifier:@"notificationListToDetails" sender:self];
    }
}

#pragma mark - IBAction's

- (IBAction)btnBackClicked:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Web Service

-(void)getNotification:(NSString*)strDatetime{
    if (APP_DELEGATE.isServerReachable) {
        
//        NSString *strEmpCode;
//        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]) {
//            strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"selected_cust_code"];
//        }else{
//            strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
//        }
        
//        NSString *strEmpCode;
//        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]) {
//            strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"selected_cust_code"];
//        }else if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"sub dealer"]){
//            strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
//        }else{
//            NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
//            FMDatabase *db = [FMDatabase databaseWithPath:path];
//            if ([db open]) {
//                FMResultSet *s = [db executeQuery:@"SELECT customer_code FROM customer_master where cust_type = 'Dealer'"];
//                while ([s next]) {
//                    strEmpCode = [s stringForColumn:@"customer_code"];
//                }
//                [db close];
//            }
//        }
        
        NSString *strBranchCode;
        if ([APP_CONSTANTS.db open]) {
            strBranchCode = [APP_CONSTANTS.db stringForQuery:@"SELECT branch_code FROM customer_master where customer_code = ?",APP_CONSTANTS.strCustCode];
            [APP_CONSTANTS.db close];
        }
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setValue:APP_CONSTANTS.strCustCode    forKey:@"the_id"];
        [dict setValue:strBranchCode                forKey:@"the_branch_code"];
        
        [SVProgressHUD showWithStatus:@"Loading..."];
        [JsonParser callAPIWithURL:@"http://starsaathi.com/SAP/acedns_show_notifications.php" parameters:dict completion:^(NSDictionary *dictResponse){
            [SVProgressHUD dismiss];
            if ([[dictResponse valueForKey:@"process_status"] isEqualToString:@"YES"]) {
                [self insertNotification:[dictResponse safeValueeForKey:@"notification_data"] dateTime:@"curr_date_time"];
            }else
                UDShowToastAlertWithTitle([dictResponse valueForKey:@"process_message"], 2);
        }];
        
    }else
        UDShowToastAlertWithTitle(kNoInternet, 2);
}

-(void)updateReadStatusWithNotificationId:(NSString*)strNotificationId{
    
    if (APP_DELEGATE.isServerReachable) {
        
//        NSString *strEmpCode;
//        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]) {
//            strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"selected_cust_code"];
//        }else{
//            strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
//        }
        
//        NSString *strEmpCode;
//        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]) {
//            strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"selected_cust_code"];
//        }else if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"sub dealer"]){
//            strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
//        }else{
//            NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
//            FMDatabase *db = [FMDatabase databaseWithPath:path];
//            if ([db open]) {
//                FMResultSet *s = [db executeQuery:@"SELECT customer_code FROM customer_master where cust_type = 'Dealer'"];
//                while ([s next]) {
//                    strEmpCode = [s stringForColumn:@"customer_code"];
//                }
//                [db close];
//            }
//        }
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setValue:APP_CONSTANTS.strCustCode    forKey:@"the_id"];
        [dict setValue:strNotificationId            forKey:@"noti_id"];
        
        //[SVProgressHUD showWithStatus:@"Loading..."];
        [JsonParser callAPIWithURL:@"http://starsaathi.com/SAP/make_notification_read_v3.php" parameters:dict completion:^(NSDictionary *dictResponse){
            //[SVProgressHUD dismiss];
            if ([[dictResponse valueForKey:@"process_status"] isEqualToString:@"YES"]) {
                [self updateStatusWithNotiId:strNotificationId];
            }
            
//            else
//                UDShowToastAlertWithTitle([dictResponse valueForKey:@"process_message"], 2);
        }];
        
    }else
        UDShowToastAlertWithTitle(kNoInternet, 2);
    
}

#pragma mark - Database Method

-(void)insertNotification:(NSArray*)arrNotification dateTime:(NSString*)strDatetime{
    
    //    CREATE TABLE "notification" ( `notification_id` INTEGER, `notification_title` TEXT, `notification_message` TEXT, `notification_image_link` TEXT, `notification_datetime` datetime, `status` TEXT, `notification_file_type` TEXT )
    
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
    FMDatabase *db = [FMDatabase databaseWithPath:path];
    if ([db open]) {
        
        for (NSDictionary *dict in arrNotification) {
            
            BOOL success = [db executeUpdate:@"INSERT INTO notification(notification_id, notification_title, notification_message, notification_image_link, notification_datetime, status, notification_file_type) VALUES(?, ?, ?, ?, ?, ?, ?)",
                            [dict safeValueeForKey:@"nid"],
                            [dict safeValueeForKey:@"m_title"],
                            [dict safeValueeForKey:@"m_message"],
                            [dict safeValueeForKey:@"m_image_link"],
                            [dict safeValueeForKey:@"n_date_time"],
                            [dict safeValueeForKey:@"the_noti_sts"],
                            [dict safeValueeForKey:@"m_file_type"]];
            if (!success) {
                AppLog(@"error = %@", [db lastErrorMessage]);
            }
        }
        [db close];
        [self showNotification];
    }
}

-(void)showNotification {
    [arrNotification removeAllObjects];
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
    FMDatabase *db = [FMDatabase databaseWithPath:path];
    if ([db open]) {
        FMResultSet *s = [db executeQuery:@"SELECT * FROM notification order by notification_datetime desc"];
        while ([s next]) {
            //retrieve values for each record
            
            NotificationBO *NBO = [[NotificationBO alloc] init];
            NBO.strNotificationId           = [s stringForColumn:@"notification_id"];
            NBO.strNotificationTitle        = [s stringForColumn:@"notification_title"];
            NBO.strNotificationMsg          = [s stringForColumn:@"notification_message"];
            NBO.strNotificationImgLink      = [s stringForColumn:@"notification_image_link"];
            NBO.strNotificationDatetime     = [s stringForColumn:@"notification_datetime"];
            NBO.strStatus                   = [s stringForColumn:@"status"];
            NBO.strNotificationType         = [s stringForColumn:@"notification_file_type"];
            [arrNotification addObject:NBO];
        }
        [db close];
        [tblViewNotification reloadData];
    }
}

-(NSString*)getStatusWithNotiId:(NSString*)strNotificationId {
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
    FMDatabase *db = [FMDatabase databaseWithPath:path];
    if ([db open]) {
        FMResultSet *s = [db executeQuery:@"SELECT status from notification where notification_id = ?",strNotificationId];
        while ([s next]) {
            AppLog(@"-->>%@",[s stringForColumn:@"status"]);
            return [s stringForColumn:@"status"];
        }
        [db close];
    }
    return @"";
}

-(void)updateStatusWithNotiId:(NSString*)strNotiId {
    
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
    FMDatabase *db = [FMDatabase databaseWithPath:path];
    if ([db open]) {
        BOOL success = [db executeUpdate:@"UPDATE notification SET status = ? WHERE notification_id = ?",@"READ",strNotiId];
        if (success) {
            [arrNotification removeAllObjects];
            [self showNotification];
        }
        AppLog(@"%d",success);
    }
    [db close];
}

#pragma mark - Segue

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    NotificationBO *nbo = [arrNotification objectAtIndex:[tblViewNotification indexPathForSelectedRow].row];
    
    if ([segue.identifier isEqualToString:@"notificationListToDetails"]) {
        NotificationDetailViewController *ndvc = [segue destinationViewController];
        ndvc.NBO = nbo;
    }else{
        WebViewController *wvc = [segue destinationViewController];
        wvc.strWeblink = nbo.strNotificationImgLink;
    }
}

@end
