//
//  NotificationDetailViewController.h
//  StarCementDealer
//
//  Created by Apple on 07/02/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NotificationBO.h"

@interface NotificationDetailViewController : UIViewController
@property(strong, nonatomic)NotificationBO *NBO;
@end
