//
//  SchemeViewController.m
//  StarCementDealer
//
//  Created by Apple on 12/02/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import "SchemeViewController.h"
#import "SchemeCell.h"
#import "BranchSchemePDFBO.h"
#import "WebViewController.h"

@interface SchemeViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>{    
    __weak IBOutlet UICollectionView *collViewScheme;
    NSMutableArray *arrBSPDF;
}

@end

@implementation SchemeViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self designView];
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Initialization Method

-(void)designView {
    [collViewScheme registerNib:[UINib nibWithNibName:@"SchemeCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
}

-(void)loadData {
    arrBSPDF = [[NSMutableArray alloc]init];
    [self loadBranchSchemePDF];
}

#pragma mark - Database Method

-(void)loadBranchSchemePDF {
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
    FMDatabase *db = [FMDatabase databaseWithPath:path];
    
//    NSString *strEmpCode;
//    if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]) {
//        strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"selected_cust_code"];
//    }else{
//        strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
//    }
    
//    if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]) {
//        strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"selected_cust_code"];
//    }else if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"sub dealer"]){
//        strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
//    }else{
//        NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
//        FMDatabase *db = [FMDatabase databaseWithPath:path];
//        if ([db open]) {
//            FMResultSet *s = [db executeQuery:@"SELECT customer_code FROM customer_master where cust_type = 'Dealer'"];
//            while ([s next]) {
//                strEmpCode = [s stringForColumn:@"customer_code"];
//            }
//            [db close];
//        }
//    }
    
    if ([APP_CONSTANTS.db open]) {
        NSString *strBranchCode = [APP_CONSTANTS.db stringForQuery:@"SELECT branch_code FROM customer_master where customer_code = ?",APP_CONSTANTS.strCustCode];
        AppLog(@"-->>%@",strBranchCode);
        
        if ([db open]) {
            //NSString *strQuery = @"select * from branch_schemes_PDF";
            NSString *strQuery = [NSString stringWithFormat:@"select * from branch_schemes_PDF where branch_code = '%@'",strBranchCode];
            FMResultSet *bs = [db executeQuery:strQuery];
            while ([bs next]) {
                //retrieve values for each record
                BranchSchemePDFBO *BSBO = [[BranchSchemePDFBO alloc]init];
                BSBO.strBranchCode      = [bs stringForColumn:@"branch_code"];
                BSBO.strPDFFileName     = [bs stringForColumn:@"PDF_file_name"];
                BSBO.strAcedns          = [bs stringForColumn:@"acedns"];
                [arrBSPDF addObject:BSBO];
            }
            [collViewScheme reloadData];
        }
        [APP_CONSTANTS.db close];
    }
    
}

#pragma mark - UICollectionView Delegate and DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return arrBSPDF.count;
}

- (SchemeCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"cell";
    SchemeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    cell.lblScheme.text = [NSString stringWithFormat:@"SCHEME %ld",(long)indexPath.row + 1];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    WebViewController *wvc = [self.storyboard instantiateViewControllerWithIdentifier:@"webvc"];
    BranchSchemePDFBO *bspdf = arrBSPDF[indexPath.item];
    NSString *strPDFLink = [NSString stringWithFormat:@"http://starsaathi.com/SAP/schemes/%@",bspdf.strPDFFileName];
    wvc.strWeblink = strPDFLink;
    wvc.title = [NSString stringWithFormat:@"SCHEME %ld",indexPath.item + 1];
    [self.navigationController pushViewController:wvc animated:YES];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    float size = (APP_CONSTANTS.fltAppWidth - 17) / 2;
    return CGSizeMake(size, size);
}

#pragma mark - IBAction's

- (IBAction)btnBackClicked:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}


@end
