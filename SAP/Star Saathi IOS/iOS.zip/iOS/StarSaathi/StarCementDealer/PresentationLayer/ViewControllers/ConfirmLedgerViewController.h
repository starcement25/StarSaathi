//
//  ConfirmLedgerViewController.h
//  StarCementDealer
//
//  Created by Apple on 09/04/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfirmLedgerViewController : UIViewController

@end
