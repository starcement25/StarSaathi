//
//  NotificationDetailViewController.m
//  StarCementDealer
//
//  Created by Apple on 07/02/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import "NotificationDetailViewController.h"
#import <UIImageView+AFNetworking.h>

@interface NotificationDetailViewController (){
    
    __weak IBOutlet UIImageView   *imgNotification;
    __weak IBOutlet UILabel       *lblTitle;
    __weak IBOutlet UILabel       *lblSubtitle;
    __weak IBOutlet UIScrollView  *scrlView;
}

@end

@implementation NotificationDetailViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self designView];
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Initialization Method

-(void)designView{
    AppLog(@"-->>%@",_NBO.strNotificationTitle);
}

-(void)loadData{
    [self setData];
    //[self updateData];
}

-(CGFloat)heightForLabel:(UILabel *)label withText:(NSString *)text{
    
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:text attributes:@{NSFontAttributeName:label.font}];
    CGRect rect = [attributedText boundingRectWithSize:(CGSize){label.frame.size.width, CGFLOAT_MAX}
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    
    return ceil(rect.size.height);
}

#pragma mark - IBAction's

- (IBAction)btnBackClicked:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Helper Method

-(void)setData{
    
    lblTitle.text = _NBO.strNotificationTitle;
    lblSubtitle.text = _NBO.strNotificationMsg;
    
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:_NBO.strNotificationImgLink]];
    [imgNotification setImageWithURLRequest:request placeholderImage:nil success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
        
        AppLog(@"-->>%f",image.size.width);
        AppLog(@"-->>%f",image.size.height);
        
        int value = (self.view.frame.size.width / image.size.width) * 100;
        float height = image.size.height * value / 100;
        AppLog(@"-->>%d",value);
        
        float yAxis = imgNotification.frame.origin.y;
        
        imgNotification.frame = CGRectMake(imgNotification.frame.origin.x, yAxis, self.view.frame.size.width, height);
        imgNotification.image = image;
        
        yAxis += imgNotification.frame.size.height + 15;
        CGFloat fltHeight = [self heightForLabel:lblTitle withText:self->_NBO.strNotificationTitle];
        lblTitle.frame = CGRectMake(lblTitle.frame.origin.x, yAxis, lblTitle.frame.size.width, fltHeight);
        
        yAxis += lblTitle.frame.size.height + 15;
        fltHeight = [self heightForLabel:lblSubtitle withText:self->_NBO.strNotificationMsg];
        lblSubtitle.frame = CGRectMake(lblSubtitle.frame.origin.x, yAxis, lblSubtitle.frame.size.width, fltHeight);
        
    } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
        AppLog(@"%@",error);
    }];
    
}

-(void)updateData{
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
    FMDatabase *db = [FMDatabase databaseWithPath:path];
    if ([db open]) {
        BOOL success = [db executeUpdate:@"UPDATE notification SET status = ? WHERE notification_id = ?",@"READ",_NBO.strNotificationId];
        if (success) {
            AppLog(@"-->>Record Updated.");
        }
        [db close];
    }
}

@end
