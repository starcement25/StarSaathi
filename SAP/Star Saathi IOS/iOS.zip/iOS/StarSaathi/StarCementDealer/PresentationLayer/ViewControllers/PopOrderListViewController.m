//
//  PopOrderListViewController.m
//  StarCementDealer
//
//  Created by Forcepower Infotech Pvt Ltd on 20/09/23.
//  Copyright © 2023 Coral . All rights reserved.
//

#import "PopOrderListViewController.h"
#import "PopOrderListCell.h"
#import <UIImageView+AFNetworking.h>
#import "NSString+CharHandling.h"
#import "UIBarButtonItem+Badge.h"
#import "PopOrderConfirmationVC.h"
#import "PopOrderHistoryCell.h"

@interface PopOrderListViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource>{
    IBOutlet UIToolbar *toolbarDone;
    __weak IBOutlet UICollectionView *collViewPop;
    __weak IBOutlet UITableView *tblViewHistory;
    NSMutableArray *arrPopProd;
    NSMutableArray *arrSelectedProd;
    NSArray *arrOrderHistory;
    UIBarButtonItem *barButtonCart;
    IBOutletCollection(UIButton) NSArray *arrBtnTab;
    IBOutlet UIView *viewer;
    __weak IBOutlet UIImageView *imgViewProd;
    __weak IBOutlet UILabel *lblProdDesc;
    __weak IBOutlet UIButton *btnCheckout;
    
    
    __weak IBOutlet UIView *viewMonthYearCal;
    __weak IBOutlet UIPickerView *pickerViewMonthYear;
    NSMutableArray *arrMonth;
    NSMutableArray *arrYear;
    NSString *strSelectedMonthYear;
}

@end

@implementation PopOrderListViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self designView];
    [self loadData];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resetPopOrderList:) name:@"resetPopOrder" object:nil];
    
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    self.navigationItem.hidesBackButton = YES;
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void) resetPopOrderList:(NSNotification *) notification {
    // [notification name] should always be @"TestNotification"
    // unless you use this method for observation of other notifications
    // as well.
    
    if ([[notification name] isEqualToString:@"resetPopOrder"]){
        AppLog (@"Successfully received the test notification!");
        [arrPopProd removeAllObjects];
        [arrSelectedProd removeAllObjects];
        arrOrderHistory = @[];
        barButtonCart.badgeValue = @"0";
        [self getProductList];
    }
    
}

#pragma mark - Initialization Method

-(void)designView {
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    NSDate *date = [NSDate date];
    [APP_CONSTANTS.dateFormater setDateFormat:@"MM"];
    NSString *month = [APP_CONSTANTS.dateFormater stringFromDate:date];
    
    strSelectedMonthYear = @"";
    
    arrMonth = [[NSMutableArray alloc] init];
    for (int monthNumber = 1; monthNumber <= 12; monthNumber++) {
        NSString *strMonthName = [[APP_CONSTANTS.dateFormater monthSymbols] objectAtIndex:(monthNumber-1)];
        [arrMonth addObject:strMonthName];
    }
    
    arrYear = [[NSMutableArray alloc] init];
    [APP_CONSTANTS.dateFormater setDateFormat:@"yyyy"];
    NSString *strYear = [APP_CONSTANTS.dateFormater stringFromDate:[NSDate date]];
    NSInteger intCurrentYear = [strYear integerValue];
    
    for (int i = 0; i < 20; i++) {
        int year = (int)intCurrentYear - i;
        [arrYear addObject:[NSString stringWithFormat:@"%d",year]];
    }
    AppLog(@"-->>%@",arrYear);
    
    [pickerViewMonthYear selectRow:[month integerValue] - 1 inComponent:0 animated:true];
    
    //self.title = [NSString stringWithFormat:@"PERFORMANCE %@, %@",[[[APP_CONSTANTS.dateFormater shortMonthSymbols] objectAtIndex:[month intValue] - 1] uppercaseString], strYear];
    //viewMonthYearCal.frame = CGRectMake(0, APP_CONSTANTS.fltAppHeight - 216, APP_CONSTANTS.fltAppWidth, 206);
    viewMonthYearCal.hidden = true;
    viewMonthYearCal.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:viewMonthYearCal];
    
    // Set up Auto Layout constraints
    [NSLayoutConstraint activateConstraints:@[
        [viewMonthYearCal.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [viewMonthYearCal.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [viewMonthYearCal.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
        [viewMonthYearCal.heightAnchor constraintEqualToConstant:206]
    ]];
    
    [self.view bringSubviewToFront:viewMonthYearCal];
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    [tblViewHistory registerNib:[UINib nibWithNibName:@"PopOrderHistoryCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    tblViewHistory.separatorColor = [UIColor clearColor];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.minimumLineSpacing = 0.0f;
    layout.minimumInteritemSpacing = 0.0f;
    layout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
    collViewPop.collectionViewLayout = layout;
    [collViewPop registerNib:[UINib nibWithNibName:@"PopOrderListCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
    
    [self showRightBarButtonItems:101];
}

-(void)loadData {
    arrSelectedProd = [[NSMutableArray alloc] init];
    arrPopProd = [[NSMutableArray alloc] init];
    [self getProductList];
}

#pragma mark - IBAction's

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)btnCheckoutClicked:(UIButton *)sender {
    [self btnCartClicked:nil];
}

- (IBAction)resignKeyboard:(id)sender {
    [self.view endEditing:YES];
}

- (IBAction)btnTabClicked:(UIButton *)sender {
    for (UIButton *btnTab in arrBtnTab) {
        [btnTab setSelected:NO];
    }
    [sender setSelected:YES];
    collViewPop.hidden = (sender.tag != 101) ? true : false;
    btnCheckout.hidden = (sender.tag != 101) ? true : false;
    
    [self showRightBarButtonItems:(int)sender.tag];
    if (sender.tag == 101) {
        viewMonthYearCal.hidden = true;
    }
    [self.view endEditing:true];
    
    if (sender.tag != 101) {
        if (!arrOrderHistory.count) {
            [self getOrderHistory];
        } else{
            [tblViewHistory reloadData];
        }
    }
    
}

- (IBAction)btnCloseViewer:(UIButton *)sender {
    [sender.superview.superview removeFromSuperview];
}

- (IBAction)btnRotateImage:(UIButton *)sender {
    imgViewProd.transform = CGAffineTransformRotate(imgViewProd.transform, M_PI_2);
}

- (IBAction)btnDoneClicked:(UIBarButtonItem *)sender {
    
    NSInteger intSelectedMonthRow = [pickerViewMonthYear selectedRowInComponent:0];
    intSelectedMonthRow += 1;
    
    NSString *strSelectedMonth = [NSString stringWithFormat:@"%02ld",(long)intSelectedMonthRow];
    NSString *strSelectedYear = arrYear[[pickerViewMonthYear selectedRowInComponent:1]];
    
    strSelectedMonthYear = [NSString stringWithFormat:@"%@-%@", strSelectedYear, strSelectedMonth];
    viewMonthYearCal.hidden = true;
    
    [self getOrderHistory];
}

#pragma mark - Navigation Item Action

- (void)btnCartClicked:(UIButton *)sender {
    AppLog(@"Hello");
    
    [arrSelectedProd removeAllObjects];
    for (NSDictionary *dictProd in arrPopProd) {
        if (![[dictProd safeValueeForKey:@"input_value"] isEqualToString:@""]) {
            
            NSInteger intMinOrderQty = [[dictProd safeValueeForKey:@"min_order_qty"] integerValue];
            NSInteger intInputQty = [[dictProd safeValueeForKey:@"input_value"] integerValue];
            
            if (intInputQty <intMinOrderQty) {
                UDShowAlertWithTitle(kAppName, @"Please follow minimum qty (Pcs)");
                return;
            }
            [arrSelectedProd addObject:dictProd];
        }
    }
    
    if (arrSelectedProd.count == 0) {
        UDShowAlertWithTitle(kAppName, @"Please select atleast one product");
        return;
    }
    
    // Key to check
    NSString *key = @"payment_gateway";
    
    // Initialize a mutable set to track unique values for the specified key
    NSMutableSet *values = [NSMutableSet set];
    
    // Iterate through the array and add each value for the key to the set if it's not empty
    for (NSDictionary *dict in arrSelectedProd) {
        NSString *value = dict[key];
        if (value && ![value isEqualToString:@""]) {
            [values addObject:value];
        }
    }
    
//    // Iterate through the array and add each value for the key to the set
//    for (NSDictionary *dict in arrSelectedProd) {
//        if (dict[key]) {
//            [values addObject:dict[key]];
//        }
//    }
    
    // Check if all values are the same or different
    if (values.count == 1) {
        AppLog(@"All values are the same: %@", values.anyObject);
    } else {
        AppLog(@"There are different values: %@", values);
        UDShowAlertWithTitle(kAppName, @"Please select only one type of product.");
        return;
    }
    
    [self performSegueWithIdentifier:@"popProdListToConfirmation" sender:self];
    AppLog(@"-->>%@",arrSelectedProd);
}

-(void)barButtonItemFilterClicked:(UIBarButtonItem*)item{
    viewMonthYearCal.hidden = false;
}

#pragma mark - Helper Method

-(void)showRightBarButtonItems:(int)tag {
    
    UIImage *imgCart = [UIImage imageNamed:@"cart"];
    UIButton *btnCart = [UIButton buttonWithType:UIButtonTypeCustom];
    btnCart.frame = CGRectMake(0,0,imgCart.size.width, imgCart.size.height);
    [btnCart addTarget:self action:@selector(btnCartClicked:) forControlEvents:UIControlEventTouchDown];
    [btnCart setBackgroundImage:imgCart forState:UIControlStateNormal];
    
    barButtonCart = [[UIBarButtonItem alloc]initWithCustomView:btnCart];
    barButtonCart.tintColor = [UIColor whiteColor];
    barButtonCart.badgeValue = @"0";
    barButtonCart.badgeBGColor = [UIColor blackColor];
    
    UIBarButtonItem *barBtnFilterOrderHistory = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"filter"] style:UIBarButtonItemStyleDone target:self action:@selector(barButtonItemFilterClicked:)];
    barBtnFilterOrderHistory.tintColor = [UIColor whiteColor];
    
    
    if (tag == 101) {
        self.navigationItem.rightBarButtonItems = @[barButtonCart];
    }else{
        self.navigationItem.rightBarButtonItems = @[barButtonCart, barBtnFilterOrderHistory];
    }
}

#pragma mark - Segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"popProdListToConfirmation"]) {
        PopOrderConfirmationVC *pocvc = segue.destinationViewController;
        pocvc.arrPickedItems = arrSelectedProd.copy;
    }
}

#pragma mark - Web Service

-(void)getProductList{
    
    if (APP_DELEGATE.isServerReachable) {
        
        NSString *strDealerId = [[NSUserDefaults standardUserDefaults] valueForKey:@"kDealerId"];
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        //[dict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"dealer_id"] forKey:@"customer_code"];
        [dict setValue:strDealerId forKey:@"customer_code"];
        [dict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] forKey:@"user_type"];
        
        [SVProgressHUD showWithStatus:@"Loading..."];
        [JsonParser callAPIWithURL:@"http://starsaathi.com/SAP/pop-product-data-download-v2.php" parameters:dict completion:^(NSDictionary *dictResponse){
            dispatch_async(dispatch_get_main_queue(), ^(void) {
                [SVProgressHUD dismiss];
                if ([[dictResponse valueForKey:@"process_status"] isEqualToString:@"YES"]) {
                    NSArray *arrProd = [dictResponse safeValueeForKey:@"pop_product_date"];
                    for (NSDictionary *dictProd in arrProd) {
                        NSMutableDictionary *dictTemp = [dictProd mutableCopy];
                        dictTemp[@"input_value"] = @"";
                        [arrPopProd addObject:dictTemp];
                    }
                    [collViewPop reloadData];
                }else
                    UDShowToastAlertWithTitle([dictResponse valueForKey:@"process_message"], 2);
            });
        }];
    }else
        UDShowToastAlertWithTitle(kNoInternet, 2);
}

-(void)getOrderHistory{
    
    if (APP_DELEGATE.isServerReachable) {
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setValue:APP_CONSTANTS.strCustCode forKey:@"customer_code"];
        [dict setValue:strSelectedMonthYear forKey:@"year_month"];
        
        [SVProgressHUD showWithStatus:@"Loading..."];
        [JsonParser callAPIWithURL:@"http://starsaathi.com/SAP/show-pop-order-list.php" parameters:dict completion:^(NSDictionary *dictResponse){
            dispatch_async(dispatch_get_main_queue(), ^(void) {
                [SVProgressHUD dismiss];
                if ([[dictResponse valueForKey:@"process_status"] isEqualToString:@"YES"]) {
                    arrOrderHistory = [dictResponse safeValueeForKey:@"track_pop_order_data"];
                    [tblViewHistory reloadData];
                }else{
                    arrOrderHistory = @[];
                    [tblViewHistory reloadData];
                    UDShowToastAlertWithTitle([dictResponse valueForKey:@"process_message"], 2);
                }
                
            });
        }];
    }else
        UDShowToastAlertWithTitle(kNoInternet, 2);
}


#pragma mark - UICollectionView Delegate and DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return arrPopProd.count;
}

- (PopOrderListCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"cell";
    PopOrderListCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    NSDictionary *dictProd = arrPopProd[indexPath.row];
    
    [cell.imgViewProd setImageWithURL:[NSURL URLWithString:[NSString handleSpecialSymbol:[dictProd safeValueeForKey:@"prod_image"]]] placeholderImage:[UIImage imageNamed:@"default-placeholder"]];
    [cell.btnShowImg addTarget:self action:@selector(btnShowImageClicked:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnShowImg.tag = indexPath.item;
    cell.lblProdDesc.text = [dictProd safeValueeForKey:@"prod_desc"];
    cell.lblPricePerPiece.text = [NSString stringWithFormat:@"Price Per Piece ₹ %@",[dictProd safeValueeForKey:@"price_per_piece"]];
    cell.lblGst.text = [NSString stringWithFormat:@"GST %@ %%",[dictProd safeValueeForKey:@"GST_rate"]];
    cell.lblMinOrderQty.text = [NSString stringWithFormat:@"Min Order Qty %@",[dictProd safeValueeForKey:@"min_order_qty"]];
    cell.txtFieldQty.text = [dictProd safeValueeForKey:@"input_value"];
    cell.txtFieldQty.inputAccessoryView = toolbarDone;
    cell.txtFieldQty.delegate = self;
    cell.txtFieldQty.tag = indexPath.row;
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake((self.view.frame.size.width / 2) - 1 , 225);
}

#pragma mark - Cell Action

-(void)btnShowImageClicked:(UIButton*)btn {
    AppLog(@"-->>%ld",(long)btn.tag);
    NSDictionary *dict = arrPopProd[btn.tag];
    
    viewer.frame = CGRectMake(0, 0, APP_CONSTANTS.fltAppWidth, APP_CONSTANTS.fltAppHeight);
    lblProdDesc.text = [dict safeValueeForKey:@"prod_desc"];
    imgViewProd.transform = CGAffineTransformIdentity;
    [imgViewProd setImageWithURL:[NSURL URLWithString:[NSString handleSpecialSymbol:[dict safeValueeForKey:@"prod_image"]]] placeholderImage:[UIImage imageNamed:@"default-placeholder"]];
    [self.view.window addSubview:viewer];
    
}

#pragma mark - UITableView Delegate and DataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrOrderHistory.count;
}

- (PopOrderHistoryCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"cell";
    PopOrderHistoryCell *cell = [tblViewHistory dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    NSDictionary *dict = arrOrderHistory[indexPath.row];
    [cell.imgViewProd setImageWithURL:[NSURL URLWithString:[NSString handleSpecialSymbol:[dict safeValueeForKey:@"image"]]] placeholderImage:[UIImage imageNamed:@"default-placeholder"]];
    cell.lblMainOrderId.text = [dict safeValueeForKey:@"main_order_id"];
    cell.lblOrderId.text = [dict safeValueeForKey:@"order_id"];
    cell.lblDate.text = [dict safeValueeForKey:@"order_date"];
    cell.lblProd.text = [dict safeValueeForKey:@"prod_display_name"];
    cell.lblQty.text = [NSString stringWithFormat:@"%@ (Pcs)",[dict safeValueeForKey:@"qty"]];
    cell.lblTotalAmt.text = [NSString stringWithFormat:@"₹ %@.00",[dict safeValueeForKey:@"total_amount"]];
    cell.lblAddress.text = [dict safeValueeForKey:@"address"];
    cell.lblOrderStatus.text = [dict safeValueeForKey:@"order_status"];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 173.0f;
}

#pragma mark - Keyboard Method

- (void)keyboardWillShow:(NSNotification *)sender {
    
    CGFloat height = [[sender.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    height -= 44;
    NSTimeInterval duration = [[sender.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    UIViewAnimationOptions curveOption = [[sender.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] unsignedIntegerValue] << 16;
    
    [UIView animateKeyframesWithDuration:duration delay:0 options:UIViewAnimationOptionBeginFromCurrentState|curveOption animations:^{
        UIEdgeInsets edgeInsets = UIEdgeInsetsMake(0, 0, height, 0);
        collViewPop.contentInset = edgeInsets;
        collViewPop.scrollIndicatorInsets = edgeInsets;
    }completion:nil];
}

- (void)keyboardWillHide:(NSNotification *)sender {
    
    NSTimeInterval duration = [[sender.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    UIViewAnimationOptions curveOption = [[sender.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] unsignedIntegerValue] << 16;
    
    [UIView animateKeyframesWithDuration:duration delay:0 options:UIViewAnimationOptionBeginFromCurrentState|curveOption animations:^{
        UIEdgeInsets edgeInsets = UIEdgeInsetsZero;
        collViewPop.contentInset = edgeInsets;
        collViewPop.scrollIndicatorInsets = edgeInsets;
    }completion:nil];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *strInputValue = [textField.text stringByReplacingCharactersInRange:range withString:string];
    NSInteger index = textField.tag;
    
    NSMutableDictionary *dictProd = [arrPopProd objectAtIndex:index];
    dictProd[@"input_value"] = strInputValue;
    
    int count = 0;
    for (NSDictionary *dictProd in arrPopProd) {
        if (![[dictProd safeValueeForKey:@"input_value"] isEqualToString:@""]) {
            count += 1;
        }
    }
    barButtonCart.badgeValue = [NSString stringWithFormat:@"%d",count];
    return true;
}

#pragma mark - UIPickerView Delegate and DataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (component == 0) {
        return arrMonth.count;
    } else {
        return arrYear.count;
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (component == 0) {
        return arrMonth[row];
    } else {
        return arrYear[row];
    }
}



@end
