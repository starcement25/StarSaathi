//
//  NavigationViewController.h
//  StarCementDealer
//
//  Created by Coral  on 16/07/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"

@interface NavigationViewController : UINavigationController

- (void)panGestureRecognized:(UIPanGestureRecognizer *)sender;

@end
