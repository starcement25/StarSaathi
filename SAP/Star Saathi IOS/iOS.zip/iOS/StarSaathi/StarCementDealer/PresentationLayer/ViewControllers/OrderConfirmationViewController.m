//
//  OrderConfirmationViewController.m
//  StarCementDealer
//
//  Created by Coral  on 04/08/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import "OrderConfirmationViewController.h"
#import "OrderConfirmationCell.h"
#import "ProductMasterBO.h"
#import <AFNetworking.h>
#import "UIAlertView+Category.h"
#import "DashboardViewController.h"
#import "NSString+CharHandling.h"


@interface OrderConfirmationViewController ()<UITableViewDataSource, UITableViewDelegate>{
    __weak IBOutlet UITableView *tblViewProduct;
    __weak IBOutlet UILabel *lblShipTo;
    __weak IBOutlet UILabel *lblConsigneeName;
    __weak IBOutlet UILabel *lblConsigneeAddress;
    __weak IBOutlet UILabel *lblFright;
    __weak IBOutlet UILabel *lblDestinationAddress;
    __weak IBOutlet UILabel *lblPhone;
    __weak IBOutlet UILabel *lblDumpDetails;
    __weak IBOutlet UILabel *lblDumpName;
    __weak IBOutlet NSLayoutConstraint *constraintTblProdHeight;
}

@end

@implementation OrderConfirmationViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self designView];
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Initialization Method

-(void)designView{
    
    constraintTblProdHeight.constant = _arrProductList.count * 30;
    
    [tblViewProduct registerNib:[UINib nibWithNibName:@"OrderConfirmationCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    tblViewProduct.separatorColor = [UIColor clearColor];
    tblViewProduct.tableFooterView = [UIView new];
}

-(void)loadData{
    AppLog(@"-->>%@",_arrProductList);
    AppLog(@"-->>%@",_strName);
    AppLog(@"-->>%@",_strAddress);
    
    float fltTotalQunatity = 0;
    for (ProductMasterBO *PMBO in _arrProductList) {
        fltTotalQunatity += [PMBO.strQuantity floatValue];
    }
    
    lblShipTo.text = [NSString stringWithFormat:@"SHIP TO : %@",_strOrderForType];
    lblConsigneeName.text = _strName;
    lblConsigneeAddress.text = _strAddress;
    lblFright.text = [NSString stringWithFormat:@"FRIEGHT : %@",_strFrieght];
    lblDestinationAddress.text = _strFrieghtAddress;
    lblPhone.text = [NSString stringWithFormat:@"PHONE : %@",_strPhoneNumber];
    lblDumpDetails.text = [NSString stringWithFormat:@"DUMP DETAILS : %@",_strDumpStatus];
    lblDumpName.text = _strDumpAddress;
    
    
    //lblTotalQuantity.text = [NSString stringWithFormat:@"%.2f QTY (MT)",fltTotalQunatity];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  _arrProductList.count;
}

- (OrderConfirmationCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"cell";
    OrderConfirmationCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    ProductMasterBO *PMBO = _arrProductList[indexPath.row];
    cell.lblProductName.text = [NSString stringWithFormat:@"%@ : %@ MT", PMBO.strProdDesc, PMBO.strQuantity];
//    cell.lblProductName.text = PMBO.strProdDesc;
//    cell.lblQuantity.text = [NSString stringWithFormat:@"%@ QTY (MT)",PMBO.strQuantity];
    return cell;
}

#pragma mark - IBAction's

- (IBAction)btnContinueClicked:(UIButton *)sender {
    
    
    if (APP_DELEGATE.isServerReachable) {
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        
//        NSString *strCustomerCode;
//        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]) {
//            strCustomerCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"selected_cust_code"];
//        }else{
//            strCustomerCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
//        }
        
//        NSString *strCustomerCode;
//        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]) {
//            strCustomerCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"selected_cust_code"];
//        }else if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"sub dealer"]){
//            strCustomerCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
//        }else{
//            NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
//            FMDatabase *db = [FMDatabase databaseWithPath:path];
//            if ([db open]) {
//                FMResultSet *s = [db executeQuery:@"SELECT customer_code FROM customer_master where cust_type = 'Dealer'"];
//                while ([s next]) {
//                    strCustomerCode = [s stringForColumn:@"customer_code"];
//                }
//                [db close];
//            }
//        }
        
        //[[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"sub dealer"]
        
        if (checkUserType(kSubDealer) == true) {
            [_arrProductList enumerateObjectsUsingBlock:^(ProductMasterBO *PMBO, NSUInteger idx, BOOL *stop){
                
//                apporderno,
//                erporderdt,
//                order_for,
//                sub_dealer_code,
//                order_for_type,
//                belong_dealer_code,
//                belong_dealer_dns_code,
//                prod_code,
//                qty,
//                sub_dealer_phone_no
                
                NSString *strAppOrderNo = [NSString stringWithFormat:@"O%@%@%lu",APP_CONSTANTS.strCustCode,getTimestamp(),(unsigned long)idx];
                NSString *strOrderFor = [NSString stringWithFormat:@"%@, %@",_strName,_strAddress];
                
                NSString *strBelongDealerCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"kBelongDealerCode"];
                NSString *strBelongDealerDnsCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"kBelongDealerDnsCode"];
                
                [dict setValue:strAppOrderNo              forKey:[NSString stringWithFormat:@"order_data[%lu][apporderno]",(unsigned long)idx]];
                [dict setValue:@""                        forKey:[NSString stringWithFormat:@"order_data[%lu][erporderdt]",(unsigned long)idx]];
                [dict setValue:strOrderFor                forKey:[NSString stringWithFormat:@"order_data[%lu][order_for]",(unsigned long)idx]];
                [dict setValue:APP_CONSTANTS.strCustCode  forKey:[NSString stringWithFormat:@"order_data[%lu][sub_dealer_code]",(unsigned long)idx]];//
                [dict setValue:@"Sub Dealer"              forKey:[NSString stringWithFormat:@"order_data[%lu][order_for_type]",(unsigned long)idx]];
                [dict setValue:strBelongDealerCode        forKey:[NSString stringWithFormat:@"order_data[%lu][belong_dealer_code]",(unsigned long)idx]];
                [dict setValue:strBelongDealerDnsCode     forKey:[NSString stringWithFormat:@"order_data[%lu][belong_dealer_dns_code]",(unsigned long)idx]];
                [dict setValue:PMBO.strProdCode           forKey:[NSString stringWithFormat:@"order_data[%lu][prod_code]",(unsigned long)idx]];
                [dict setValue:PMBO.strQuantity           forKey:[NSString stringWithFormat:@"order_data[%lu][qty]",(unsigned long)idx]];
                [dict setValue:_strPhoneNumber            forKey:[NSString stringWithFormat:@"order_data[%lu][sub_dealer_phone_no]",(unsigned long)idx]];
                
            }];
            
            [dict setValue:@"Sub Dealer" forKey:@"user_type"];
            [dict setValue:@"" forKey:@"login_user_id"];//
            
            AppLog(@"-->>%@",dict);
            
            NSError *error;
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                               options:0
                                                                 error:&error];
            
            if (! jsonData) {
                AppLog(@"Got an error: %@", error);
            } else {
                NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                AppLog(@"-->>%@",jsonString);
            }
            
            
            [SVProgressHUD showWithStatus:@"Uploading..."];
            AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
            manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
            [SVProgressHUD show];
            [manager POST:@"http://starsaathi.com/SAP/acedns_star_save_subdealer_app_order.php" parameters:dict progress:nil success:^(NSURLSessionTask *task, id responseObject) {
                AppLog(@"-->>%@",responseObject);
                [SVProgressHUD dismiss];
                sender.enabled = YES;
                if ([[responseObject safeValueeForKey:@"process_status"] isEqualToString:@"YES"]) {
                    UDShowToastAlertWithTitle([responseObject safeValueeForKey:@"process_message"], 2);
                    [self performSegueWithIdentifier:@"confirmatonToThankYou" sender:self];
                }else{
                    UDShowToastAlertWithTitle([responseObject safeValueeForKey:@"process_message"], 2);
                }
                
            } failure:^(NSURLSessionTask *operation, NSError *error) {
                [SVProgressHUD dismiss];
                UDShowToastAlertWithTitle(error.localizedDescription, 2);
            }];
            
            
        }else{
            
            
            
            [_arrProductList enumerateObjectsUsingBlock:^(ProductMasterBO *PMBO, NSUInteger idx, BOOL *stop){
                
                NSString *strEmpCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_code"];
                //NSString *strCustomerCode = APP_CONSTANTS.strCustCode;
                NSString *strAppOrderNo = [NSString stringWithFormat:@"O%@%@%lu",strEmpCode,getTimestamp(),(unsigned long)idx];
                NSString *strOrderFor = [NSString stringWithFormat:@"%@, %@",_strName,_strAddress];
                
                [dict setValue:strAppOrderNo              forKey:[NSString stringWithFormat:@"order_data[%lu][apporderno]",(unsigned long)idx]];//
                [dict setValue:@""                        forKey:[NSString stringWithFormat:@"order_data[%lu][erporderdt]",(unsigned long)idx]];//
                [dict setValue:strOrderFor                forKey:[NSString stringWithFormat:@"order_data[%lu][order_for]",(unsigned long)idx]];//
                [dict setValue:APP_CONSTANTS.strCustCode  forKey:[NSString stringWithFormat:@"order_data[%lu][customer_code]",(unsigned long)idx]];//
                [dict setValue:PMBO.strProdCode           forKey:[NSString stringWithFormat:@"order_data[%lu][prod_code]",(unsigned long)idx]];//
                [dict setValue:PMBO.strQuantity           forKey:[NSString stringWithFormat:@"order_data[%lu][qty]",(unsigned long)idx]];//
                [dict setValue:_strDestinationName        forKey:[NSString stringWithFormat:@"order_data[%lu][destination_name]",(unsigned long)idx]];
                [dict setValue:_strDestinationCode        forKey:[NSString stringWithFormat:@"order_data[%lu][destination_code]",(unsigned long)idx]];
                
                [dict setValue:_strFrieght                forKey:[NSString stringWithFormat:@"order_data[%lu][freight]",(unsigned long)idx]];
                [dict setValue:_strFrieghtAddress         forKey:[NSString stringWithFormat:@"order_data[%lu][destination_address]",(unsigned long)idx]];
                [dict setValue:_strPhoneNumber            forKey:[NSString stringWithFormat:@"order_data[%lu][phone_no]",(unsigned long)idx]];
                [dict setValue:_strDumpStatus             forKey:[NSString stringWithFormat:@"order_data[%lu][dump_status]",(unsigned long)idx]];
                [dict setValue:_strDumpAddress            forKey:[NSString stringWithFormat:@"order_data[%lu][dump_name]",(unsigned long)idx]];
                [dict setValue:_strDealerTruckStatus      forKey:[NSString stringWithFormat:@"order_data[%lu][dealer_truck]",(unsigned long)idx]];
                
                [dict setValue:_strSubDealerId            forKey:[NSString stringWithFormat:@"order_data[%lu][sub_dealer_code]",(unsigned long)idx]];
                [dict setValue:_strDumpCode               forKey:[NSString stringWithFormat:@"order_data[%lu][dump_code]",(unsigned long)idx]];
                [dict setValue:_strOrderForType           forKey:[NSString stringWithFormat:@"order_data[%lu][order_for_type]",(unsigned long)idx]];
                
                [dict setValue:_strDeliveryPoint          forKey:[NSString stringWithFormat:@"order_data[%lu][Delivery_point]",(unsigned long)idx]];
                [dict setValue:_strDeliveryRemarks        forKey:[NSString stringWithFormat:@"order_data[%lu][Remarks_text]",(unsigned long)idx]];
                
                
            }];
            
            //[[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"broker"]
            
            if (checkUserType(kbroker) == true) {
                [dict setValue:@"BROKER"     forKey:@"user_type"];
                [dict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"dns_broker_id"] forKey:@"login_user_id"];
            }else{
                [dict setValue:@"DEALER"     forKey:@"user_type"];
            }
            
            AppLog(@"-->>%@",dict);
            
            NSError *error;
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                               options:0
                                                                 error:&error];
            
            if (! jsonData) {
                AppLog(@"Got an error: %@", error);
            } else {
                NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                AppLog(@"-->>%@",jsonString);
            }
            
            
            [SVProgressHUD showWithStatus:@"Uploading..."];
            AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
            manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
            [SVProgressHUD show];
            [manager POST:@"http://starsaathi.com/SAP/acedns_star_save_online_offline_app_order_new_v4.php" parameters:dict progress:nil success:^(NSURLSessionTask *task, id responseObject) {
                AppLog(@"-->>%@",responseObject);
                [SVProgressHUD dismiss];
                sender.enabled = YES;
                if ([[responseObject safeValueeForKey:@"process_status"] isEqualToString:@"YES"]) {
                    UDShowToastAlertWithTitle([responseObject safeValueeForKey:@"process_message"], 2);
                    [self performSegueWithIdentifier:@"confirmatonToThankYou" sender:self];
                }else{
                    UDShowToastAlertWithTitle([responseObject safeValueeForKey:@"process_message"], 2);
                }
                
            } failure:^(NSURLSessionTask *operation, NSError *error) {
                [SVProgressHUD dismiss];
                UDShowToastAlertWithTitle(error.localizedDescription, 2);
            }];
        }
        
    }else
        UDShowToastAlertWithTitle(kNoInternet, 2);  
    
}

- (IBAction)btnBackClicked:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
