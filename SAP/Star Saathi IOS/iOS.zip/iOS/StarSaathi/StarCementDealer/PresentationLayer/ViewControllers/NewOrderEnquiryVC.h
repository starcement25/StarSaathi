//
//  NewOrderEnquiryVC.h
//  StarCementDealer
//
//  Created by Forcepower Infotech Pvt Ltd on 06/12/24.
//  Copyright © 2024 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NewOrderEnquiryVC : UIViewController

@end

NS_ASSUME_NONNULL_END
