//
//  RssdLedgerViewController.h
//  StarCementDealer
//
//  Created by Sanjeet Kumar on 23/02/23.
//  Copyright © 2023 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RssdLedgerViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
