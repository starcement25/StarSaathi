//
//  LedgerStatementViewController.m
//  StarCementDealer
//
//  Created by Forcepower Infotech Pvt Ltd on 24/06/23.
//  Copyright © 2023 Coral . All rights reserved.
//

#import "LedgerStatementViewController.h"
#import <WebKit/WebKit.h>
#import <AFNetworking.h>

@interface LedgerStatementViewController ()<WKNavigationDelegate>{
    __weak IBOutlet WKWebView *fpWebView;
    __weak IBOutlet UIActivityIndicatorView *activityIndicator;
}

@end

@implementation LedgerStatementViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self designView];
    [self loadData];
}

#pragma mark - Initialization Method

-(void)designView {
    UINavigationBar *bar = [self.navigationController navigationBar];
    [bar setBackgroundColor:UIColorFromRGB(0xEB2228)];
    
    if (@available(iOS 13.0, *)) {
        UIView *statusBar = [[UIView alloc]initWithFrame:[UIApplication sharedApplication].keyWindow.windowScene.statusBarManager.statusBarFrame] ;
        statusBar.backgroundColor = UIColorFromRGB(0xEB2228);
        [[UIApplication sharedApplication].keyWindow addSubview:statusBar];
    } else {
        // Fallback on earlier versions
    }
    
    fpWebView.navigationDelegate = self;
    fpWebView.contentMode = UIViewContentModeScaleAspectFit;
    
    NSString *jScript = @"var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);";
    
    WKUserScript *wkUScript = [[WKUserScript alloc] initWithSource:jScript injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
    
    //Here you can customize configuration
    [fpWebView.configuration.userContentController addUserScript:wkUScript];
    
    [activityIndicator setHidden:YES];
}

-(void)loadData {
    self.title = self.strTitle;
    
    NSURL *url = [NSURL URLWithString:self.strWeblink];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    [fpWebView loadRequest:requestObj];
}

#pragma mark - IBAction's

- (IBAction)btnBackClicked:(UIBarButtonItem *)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)btnDownloadClicked:(id)sender {
    [self savePDF];
}

#pragma mark - WebView Delegate

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    activityIndicator.hidden = NO;
    [activityIndicator startAnimating];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    activityIndicator.hidden = YES;
    [activityIndicator stopAnimating];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    activityIndicator.hidden = YES;
    [activityIndicator stopAnimating];
}

#pragma mark - Helper Method

-(void)savePDF {
//    NSFileManager *fileManager = [NSFileManager defaultManager];
//    NSURL *documentPath = [[fileManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
//    AppLog(@"-->>%@",documentPath.absoluteString);
//    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.strWeblink]];
//    [fileManager createFileAtPath:[documentPath.path stringByAppendingPathComponent:@"Ledger_statement.pdf"]  contents:data attributes:nil];
//
//    [self loadPDFAndShare];
    
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
        AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
        NSURL *URL = [NSURL URLWithString:self.strWeblink];
        NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
        [SVProgressHUD show];
        NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
            NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
            return [documentsDirectoryURL URLByAppendingPathComponent:@"Ledger_statement.pdf"];
        } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
            [SVProgressHUD dismiss];
    
            if (error) {
                [SVProgressHUD showErrorWithStatus:error.localizedDescription];
            } else {
                AppLog(@"File downloaded to: %@", filePath);
                [SVProgressHUD dismiss];
                [self loadPDFAndShare];
            }
        }];
        [downloadTask resume];
}

-(void)loadPDFAndShare {
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *documentPath = [[fileManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    NSString *strDocPath = [documentPath.path stringByAppendingPathComponent:@"Ledger_statement.pdf"];
    
    if ([fileManager fileExistsAtPath:strDocPath]) {
        NSData *data = [NSData dataWithContentsOfFile:strDocPath];
        UIActivityViewController *activityController = [[UIActivityViewController alloc] initWithActivityItems:@[data] applicationActivities:nil];
        [self presentViewController:activityController animated:true completion:nil];
    }
    
}


@end
