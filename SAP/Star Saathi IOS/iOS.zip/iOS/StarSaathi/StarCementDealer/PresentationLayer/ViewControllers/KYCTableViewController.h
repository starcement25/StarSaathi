//
//  KYCTableViewController.h
//  StarCementDealer
//
//  Created by Apple on 08/02/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KYCTableViewController : UITableViewController

@end
