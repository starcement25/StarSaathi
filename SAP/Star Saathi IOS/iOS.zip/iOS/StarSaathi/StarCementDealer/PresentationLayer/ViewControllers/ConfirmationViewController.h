//
//  ConfirmationViewController.h
//  StarCementDealer
//
//  Created by Apple on 04/09/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfirmationViewController : UIViewController

@end
