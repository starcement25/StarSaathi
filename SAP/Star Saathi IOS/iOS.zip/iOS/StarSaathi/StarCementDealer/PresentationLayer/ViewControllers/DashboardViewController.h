//
//  DashboardViewController.h
//  StarCementDealer
//
//  Created by Coral  on 04/07/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashboardViewController : UIViewController
@property(strong, nonatomic)NSString *strPreviousViewIdentifier;
@end
