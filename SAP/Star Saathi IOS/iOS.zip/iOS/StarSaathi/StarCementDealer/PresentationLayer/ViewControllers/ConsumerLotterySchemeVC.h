//
//  ConsumerLotterySchemeVC.h
//  StarCementDealer
//
//  Created by Forcepower Infotech Pvt Ltd on 21/01/25.
//  Copyright © 2025 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ConsumerLotterySchemeVC : UIViewController

@end

NS_ASSUME_NONNULL_END
