//
//  SplashViewController.m
//  StarCementDealer
//
//  Created by Coral  on 04/06/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import "SplashViewController.h"
#import "XMLParser.h"
#import "XMLReader.h"
#import "FMDB.h"
#import "BaseJSONParser.h"
#import "DeviceId.h"

@interface SplashViewController (){
    NSUserDefaults *defaults;
}
@property(strong, nonatomic)NSString *fileName;
@property(strong, nonatomic)NSString *filePath;

@end

@implementation SplashViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self designView];
//    [self loadData];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [self createAndCheckDatabase];
    [self designView];
    [self loadData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Initialization Method

-(void)designView{
//    if (@available(iOS 15.0, *)) {
//        UINavigationBarAppearance *navBarAppearance = [[UINavigationBarAppearance alloc] init];
//        [navBarAppearance configureWithOpaqueBackground];
//        navBarAppearance.backgroundColor = UIColorFromRGB(0xEB2228);
//        [navBarAppearance setTitleTextAttributes:
//         @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
//
//        self.navigationController.navigationBar.standardAppearance = navBarAppearance;
//        self.navigationController.navigationBar.scrollEdgeAppearance = navBarAppearance;
//    }
    
    
    //self.navigationController.view.backgroundColor = UIColorFromRGB(0xEB2228);
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    [bar setBackgroundColor:UIColorFromRGB(0xEB2228)];
    
    CGFloat statusBarHeight;
    if (@available(iOS 11.0, *)) {
        statusBarHeight = UIApplication.sharedApplication.keyWindow.safeAreaInsets.top;
    } else {
        statusBarHeight = [UIApplication sharedApplication].statusBarFrame.size.height;
    }
    
    if (@available(iOS 13.0, *)) {
        UIView *statusBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_CONSTANTS.fltAppWidth, statusBarHeight)] ;
        statusBar.backgroundColor = UIColorFromRGB(0xEB2228);
        [[UIApplication sharedApplication].keyWindow addSubview:statusBar];
    } else {
        // Fallback on earlier versions
    }




    
}

-(void)loadData{
    
//    AppLog(@"-->>DeviceId : %@",APP_CONSTANTS.strDeviceId);
    AppLog(@"-->>>%@",[DeviceId GetDeviceID]); 
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    defaults = [NSUserDefaults standardUserDefaults];
    BOOL isTableStructureDownloaded = [defaults boolForKey:@"tablestructure"];
    
    if (isTableStructureDownloaded) {
        //[self performSegueWithIdentifier:@"splashToDashboard" sender:self];
        
        BOOL flag = [[NSUserDefaults standardUserDefaults] boolForKey:@"datadownloaded"];
        if (flag) {
            [self performSegueWithIdentifier:@"splashToDashboard" sender:self];
        }else{
            [self performSegueWithIdentifier:@"splashToLogin" sender:self];
        }
    }else{
        [self checkNicknameAndDownloadTableStructure];
    }
    
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
}

//- (void)createAndCheckDatabase {
//    BOOL success;
//
//    NSFileManager *fileManager = [NSFileManager defaultManager];
//    success = [fileManager fileExistsAtPath:self.filePath];
//
//    if (success) return;
//
//    NSString *filePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:self.fileName];
//
//    [fileManager copyItemAtPath:filePathFromApp toPath:self.filePath error:nil];
//}

#pragma mark - Web Service Method

-(void)checkNicknameAndDownloadTableStructure{
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://starsaathi.com/SAP/user-details-incremental-6.0.0.php?nick_name=%@&mode=%@", @"START", @"SETUP"]];
    
    [XMLParser downloadDataFromURL:url withCompletionHandler:^(NSData *data){
        if (data != nil) {
            NSError *parseError = nil;
            NSDictionary *xmlDictionary = [XMLReader dictionaryForXMLData:data error:&parseError];
            AppLog(@"-->>%@",xmlDictionary);
        }
        
        NSURL *urlTblStructure = [NSURL URLWithString:[NSString stringWithFormat:@"http://starsaathi.com/SAP/table-structure-details-6.0.2.php?nick_name=%@&mode=%@&device_id=%@emp_code=%@", @"START", @"INSTALL", [DeviceId GetDeviceID], @""]];
        
        [XMLParser downloadDataFromURL:urlTblStructure withCompletionHandler:^(NSData *data){
            if (data != nil) {
                NSError *parseError = nil;
                NSDictionary *xmlDictionary = [XMLReader dictionaryForXMLData:data error:&parseError];
                AppLog(@"%@",xmlDictionary);
                NSDictionary *dict = [XMLReader dictionaryForXMLData:data
                                                             options:XMLReaderOptionsProcessNamespaces
                                                               error:&parseError];
                
                NSArray *arr = dict[@"recordset"][@"data"];
                AppLog(@"%@",arr);
                
                NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:kSqliteFile];
                FMDatabase *db = [FMDatabase databaseWithPath:path];
                
                for (NSDictionary *dictt in arr) {
                    AppLog(@"-->>%@",dictt[@"table_structure"][@"text"]);
                    NSString *strQuery = dictt[@"table_structure"][@"text"];
                    if ([db open]) {
                        BOOL success = [db executeStatements:strQuery];
                        AppLog(@"-->>%d",success);
                    }
                }
                
                [defaults setBool:YES forKey:@"tablestructure"];
                [defaults synchronize];
                
                //[self performSegueWithIdentifier:@"splashToDashboard" sender:self];
                [self performSegueWithIdentifier:@"splashToLogin" sender:self];
            }
        }];
    }];
}

#pragma mark - Database Method

- (void)createAndCheckDatabase {
    
    BOOL success;
    NSError *error;
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"StarSaathi.db"];
    
    success = [fileManager fileExistsAtPath:filePath];
    if (!success) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"StarSaathi" ofType:@"db"];
        success = [fileManager copyItemAtPath:path toPath:filePath error:&error];
        
    }
    
}

@end
