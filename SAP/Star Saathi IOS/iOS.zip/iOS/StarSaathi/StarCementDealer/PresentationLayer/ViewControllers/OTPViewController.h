//
//  OTPViewController.h
//  StarCementDealer
//
//  Created by Coral  on 17/08/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OTPViewController : UITableViewController
@property(nonatomic , copy)NSDictionary *dictOTP;
@property(nonatomic , strong)NSString *strDealerId;
@end
