//
//  TermsViewController.h
//  StarCementDealer
//
//  Created by Sanjeet Kumar on 07/07/20.
//  Copyright © 2020 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TermsViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
