//
//  WebViewController.h
//  StarCementDealer
//
//  Created by Apple on 12/02/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController
@property(strong, nonatomic)NSString *strWeblink;
@property(strong, nonatomic)NSString *strTitle;
@end
