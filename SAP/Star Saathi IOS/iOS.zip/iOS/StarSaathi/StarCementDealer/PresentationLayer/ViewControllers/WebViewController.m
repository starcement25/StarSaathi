//
//  WebViewController.m
//  StarCementDealer
//
//  Created by Apple on 12/02/19.
//  Copyright © 2019 Coral . All rights reserved.
//

#import "WebViewController.h"
#import <WebKit/WebKit.h>
#import "DashboardViewController.h"
#import <AFNetworking.h>

@interface WebViewController ()<WKNavigationDelegate>{
    __weak IBOutlet WKWebView *webViewNotification;
    __weak IBOutlet UIActivityIndicatorView *activityIndicator;
}

@end

@implementation WebViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];    
    [self designView];
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Initialization Method

-(void)designView{
    
    if ([self.strTitle isEqualToString:@"PDF"]) {
        UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Download" style:UIBarButtonItemStyleDone target:self action:@selector(btnDownloadClicked:)];
        rightBarButtonItem.tintColor = [UIColor whiteColor];
        self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    }    
    
    UINavigationBar *bar = [self.navigationController navigationBar];
    [bar setBackgroundColor:UIColorFromRGB(0xEB2228)];
    
    if (@available(iOS 13.0, *)) {
        UIView *statusBar = [[UIView alloc]initWithFrame:[UIApplication sharedApplication].keyWindow.windowScene.statusBarManager.statusBarFrame] ;
        statusBar.backgroundColor = UIColorFromRGB(0xEB2228);
        [[UIApplication sharedApplication].keyWindow addSubview:statusBar];
    } else {
        // Fallback on earlier versions
    }
    
    webViewNotification.navigationDelegate = self;
    webViewNotification.contentMode = UIViewContentModeScaleAspectFit;
    
    NSString *jScript = @"var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);";
    
    WKUserScript *wkUScript = [[WKUserScript alloc] initWithSource:jScript injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
    
    //Here you can customize configuration
    [webViewNotification.configuration.userContentController addUserScript:wkUScript];
    
    [activityIndicator setHidden:YES];
}

-(void)loadData{
    
    self.title = self.strTitle;
    
    NSURL *url = [NSURL URLWithString:self.strWeblink];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    [webViewNotification loadRequest:requestObj];
}

#pragma mark - IBAction's

- (IBAction)btnBackClicked:(UIBarButtonItem *)sender {
    
    if ([self.strTitle isEqualToString:@"Ledger"]) {
        for (UIViewController *controller in self.navigationController.viewControllers) {
            if ([controller isKindOfClass:[DashboardViewController class]]) {
                [self.navigationController popToViewController:controller animated:YES];
                return;
            }
        }
    }else if ([self.strTitle isEqualToString:@"PDF"]){
        [self.navigationController popViewControllerAnimated:true];
    }else{
        DashboardViewController *dvc = [self.storyboard instantiateViewControllerWithIdentifier:@"dashboardViewController"];
        [self.navigationController pushViewController:dvc animated:NO];
    }
}

- (void)btnDownloadClicked:(id)sender {
    [self savePDF];
}

#pragma mark - WebView Delegate

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    activityIndicator.hidden = NO;
    [activityIndicator startAnimating];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    activityIndicator.hidden = YES;
    [activityIndicator stopAnimating];
    
    if ([self.strTitle isEqualToString:@"Ledger"]) {
        AppLog(@"-->>%@",webView.URL.absoluteString);
        NSString *strCurrentUrl = webView.URL.absoluteString;
        if ([strCurrentUrl isEqualToString:@"http://starsaathi.com/SAP/ccavenue_pg/the_success_url.php"] || [strCurrentUrl isEqualToString:@"http://starsaathi.com/SAP/ccavenue_pg/the_success_url_ne.php"]) {
            //UDShowToastAlertWithTitle(@"Payment success.", 2);
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:@"Thank You your Transaction is successful" preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                for (UIViewController *controller in self.navigationController.viewControllers) {
                    if ([controller isKindOfClass:[DashboardViewController class]]) {
                        [self.navigationController popToViewController:controller animated:YES];
                        return;
                    }
                }
            }]];
            [self presentViewController:alert animated:true completion:nil];
            
        }else if ([strCurrentUrl isEqualToString:@"http://starsaathi.com/SAP/ccavenue_pg/the_cancel_url.php"] || [strCurrentUrl isEqualToString:@"http://starsaathi.com/SAP/ccavenue_pg/the_cancel_url_ne.php"]){
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:@"Transaction Cancelled. Please Try Again." preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                for (UIViewController *controller in self.navigationController.viewControllers) {
                    if ([controller isKindOfClass:[DashboardViewController class]]) {
                        [self.navigationController popToViewController:controller animated:YES];
                        return;
                    }
                }
            }]];
            [self presentViewController:alert animated:true completion:nil];
        }
    }
}

- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    activityIndicator.hidden = YES;
    [activityIndicator stopAnimating];
}

#pragma mark - Helper Method

-(void)savePDF {
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSURL *URL = [NSURL URLWithString:self.strWeblink];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    [SVProgressHUD show];
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
        NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
        return [documentsDirectoryURL URLByAppendingPathComponent:@"Invoice_statement.pdf"];
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
        [SVProgressHUD dismiss];
        
        if (error) {
            [SVProgressHUD showErrorWithStatus:error.localizedDescription];
        } else {
            AppLog(@"File downloaded to: %@", filePath);
            [SVProgressHUD dismiss];
            [self loadPDFAndShare];
        }
    }];
    [downloadTask resume];
}

-(void)loadPDFAndShare {
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *documentPath = [[fileManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    NSString *strDocPath = [documentPath.path stringByAppendingPathComponent:@"Invoice_statement.pdf"];
    
    if ([fileManager fileExistsAtPath:strDocPath]) {
        NSData *data = [NSData dataWithContentsOfFile:strDocPath];
        UIActivityViewController *activityController = [[UIActivityViewController alloc] initWithActivityItems:@[data] applicationActivities:nil];
        [self presentViewController:activityController animated:true completion:nil];
    }
    
}

@end
