//
//  MenuViewController.m
//  StarCementDealer
//
//  Created by Coral  on 16/07/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import "MenuViewController.h"
#import "UIViewController+REFrostedViewController.h"
#import "NavigationViewController.h"
#import "XMLParser.h"
#import "LoginViewController.h"
#import "SplashViewController.h"
#import "HelpViewController.h"
#import <MessageUI/MessageUI.h>
#import "KYCTableViewController.h"
#import "YellowCartViewController.h"
#import "TermsViewController.h"
#import "PrivacyViewController.h"
#import "RefundViewController.h"
#import <AFNetworking.h>
#import <UIImageView+AFNetworking.h>
#import "CreditLimitViewController.h"
#import "WebViewController.h"
#import "AddLiftingViewController.h"
#import "LiftingHistoryViewController.h"
#import "DealerLiftingHistoryVC.h"
#import "DealerVisitListVC.h"
#import "ConsumerLotterySchemeVC.h"

@interface MenuViewController ()<MFMailComposeViewControllerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate>{
    NSArray *arrMenu;
    UILabel *labelName;
    UIImageView *imageView;
    NSData *imageData;
}

@end

@implementation MenuViewController

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self loadData];
    [self designView];
    
    NSString *strProfilePic = [[NSUserDefaults standardUserDefaults] valueForKey:@"profile_image"];
    
    [imageView setImageWithURL:[NSURL URLWithString:strProfilePic] placeholderImage:[UIImage imageNamed:@"user_placeholder"]];
    
    //labelName.text = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_name"];
}

#pragma mark - Initialization Method

-(void)designView{
    //self.tableView.separatorColor = [UIColor colorWithRed:150/255.0f green:161/255.0f blue:177/255.0f alpha:1.0f];
    self.tableView.separatorColor = [UIColor clearColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    //self.tableView.opaque = NO;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableFooterView = [UIView new];
    self.tableView.tableHeaderView = ({
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 184.0f)];
        view.backgroundColor = [UIColor colorWithRed:0.945 green:0.961 blue:0.969 alpha:1.00];
        imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 40, 100, 100)];
        imageView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        imageView.image = [UIImage imageNamed:@"user_placeholder"];
        imageView.layer.masksToBounds = YES;
        imageView.layer.cornerRadius = 50.0;
        imageView.layer.borderColor = [UIColor whiteColor].CGColor;
        imageView.layer.borderWidth = 3.0f;
        imageView.backgroundColor = [UIColor lightGrayColor];
        imageView.layer.rasterizationScale = [UIScreen mainScreen].scale;
        imageView.layer.shouldRasterize = YES;
        imageView.clipsToBounds = YES;
        imageView.userInteractionEnabled = true;
        [imageView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imgViewUserTapped:)]];
        
        labelName = [[UILabel alloc] initWithFrame:CGRectMake(0, 150, 0, 24)];
        //label.text = @"Username";
        AppLog(@"-->>%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"emp_name"]);
        labelName.text = [[NSUserDefaults standardUserDefaults] valueForKey:@"emp_name"];
        labelName.font = [UIFont fontWithName:@"HelveticaNeue" size:17];
        labelName.backgroundColor = [UIColor clearColor];
        labelName.textColor = [UIColor colorWithRed:0.000 green:0.216 blue:0.584 alpha:1.00];
        [labelName sizeToFit];
        labelName.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        
        [view addSubview:imageView];
        [view addSubview:labelName];
        view;
    });
}

-(void)loadData{
    
    AppLog(@"-->>%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"]);
    if (checkUserType(kDealer) == true) {
        arrMenu = @[@"About Us", @"Help", @"KYC", @"App Payment History",@"Issues",@"Dealer Visit",@"Terms and Conditions",@"Privacy Policy",@"Refund Policy",@"Credit Limit", @"Lifting History", @"Consumer Lottery Scheme", @"Logout"];
    }else{
        arrMenu = @[@"About Us", @"Help", @"KYC", @"Issues",@"Dealer Visit", @"Terms and Conditions", @"Privacy Policy", @"Refund Policy", @"Consumer Lottery Scheme", @"Logout"];
    }
    [self.tableView reloadData];
}


#pragma mark - IBAction's

-(void)imgViewUserTapped:(UITapGestureRecognizer*)gesture {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            UDShowToastAlertWithTitle(@"Device has no camera", 2);
            return ;
        }
        
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        
        [self presentViewController:picker animated:YES completion:NULL];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Gallery" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        
        [self presentViewController:picker animated:YES completion:NULL];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action){
        
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
    
}

#pragma mark -
#pragma mark - UITableView Datasource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 54;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex {
    return arrMenu.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.textLabel.text = arrMenu[indexPath.row];
    return cell;
}

#pragma mark -
#pragma mark UITableView Delegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = [UIColor colorWithRed:0.000 green:0.216 blue:0.584 alpha:1.00];
    cell.textLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:17];
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NavigationViewController *navigationController = [self.storyboard instantiateViewControllerWithIdentifier:@"contentController"];
    
    NSString *strMenuItem = arrMenu[indexPath.row];
    
    if ([strMenuItem isEqualToString:@"About Us"]) {
        
        WebViewController *wvc = [self.storyboard instantiateViewControllerWithIdentifier:@"webvc"];
        wvc.strWeblink = @"http://starsaathi.com/SAP/weblink/about.html";
        wvc.strTitle = strMenuItem;
        navigationController.viewControllers = @[wvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Help"]) {
        
        HelpViewController *hvc = [self.storyboard instantiateViewControllerWithIdentifier:@"helpViewController"];
        navigationController.viewControllers = @[hvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Issues"]){
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil
                                                                                 message:nil
                                                                          preferredStyle:UIAlertControllerStyleActionSheet];
        
        NSArray *arr = @[@"Call",@"Email"];
        for (NSString *str in arr) {
            UIAlertAction *action = [UIAlertAction actionWithTitle:str
                                                             style:UIAlertActionStyleDefault
                                                           handler:^(UIAlertAction *action) {
                if ([action.title isEqualToString:@"Call"]) {
                    NSString *phoneNumber = [@"tel://" stringByAppendingString:@"180034534500"];
                    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber] options:@{} completionHandler:nil];
                }else{
                    // Check if your app support the email.
                    if ([MFMailComposeViewController canSendMail]) {
                        // Email Subject
                        NSString *emailTitle = @"";
                        // Email Content
                        NSString *messageBody = @"";
                        // To address
                        NSArray *toRecipents = [NSArray arrayWithObject:@"customercare@starcement.co.in"];
                        
                        MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
                        mc.mailComposeDelegate = self;
                        [mc setSubject:emailTitle];
                        [mc setMessageBody:messageBody isHTML:NO];
                        [mc setToRecipients:toRecipents];
                        
                        // Present mail view controller on screen
                        [self presentViewController:mc animated:YES completion:NULL];
                    }
                }
            }];
            [alertController addAction:action];
        }
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel"
                                                               style:UIAlertActionStyleCancel
                                                             handler:^(UIAlertAction *action) {
        }];
        [alertController addAction:cancelAction];
        [self presentViewController:alertController animated:YES completion:nil];
        return;
        
    }else if ([strMenuItem isEqualToString:@"KYC"]){
        
        KYCTableViewController *kycvc = [self.storyboard instantiateViewControllerWithIdentifier:@"kyctvc"];
        navigationController.viewControllers = @[kycvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Yellow Card"]){
        
        YellowCartViewController *ycvc = [self.storyboard instantiateViewControllerWithIdentifier:@"yellowCartVC"];
        navigationController.viewControllers = @[ycvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Terms and Conditions"]){
        
        TermsViewController *ycvc = [self.storyboard instantiateViewControllerWithIdentifier:@"termsVC"];
        navigationController.viewControllers = @[ycvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Privacy Policy"]){
        
        PrivacyViewController *ycvc = [self.storyboard instantiateViewControllerWithIdentifier:@"privacyVC"];
        navigationController.viewControllers = @[ycvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Refund Policy"]){
        
        RefundViewController *ycvc = [self.storyboard instantiateViewControllerWithIdentifier:@"refundVC"];
        navigationController.viewControllers = @[ycvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Credit Limit"]){
        
        CreditLimitViewController *clvc = [self.storyboard instantiateViewControllerWithIdentifier:@"creditLimitVC"];
        navigationController.viewControllers = @[clvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"App Payment History"]){
        
        NSString *strWeblink = [NSString stringWithFormat:@"http://starsaathi.com/SAP/weblink/my_payment_history_weblink.php?the_id=%@",APP_CONSTANTS.strCustCode];
        WebViewController *wvc = [self.storyboard instantiateViewControllerWithIdentifier:@"webvc"];
        wvc.strWeblink = strWeblink;
        wvc.strTitle = strMenuItem;
        navigationController.viewControllers = @[wvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"ARC Consumer Scheme"]){
        
        NSString *strWeblink = [NSString stringWithFormat:@"http://starsaathi.com/SAP/arc_offer/index.php?login_user_id=%@&user_type=dealer",APP_CONSTANTS.strCustCode];
        WebViewController *wvc = [self.storyboard instantiateViewControllerWithIdentifier:@"webvc"];
        wvc.strWeblink = strWeblink;
        wvc.strTitle = strMenuItem;
        navigationController.viewControllers = @[wvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Add Lifting"]){
        
        AddLiftingViewController *alvc = [self.storyboard instantiateViewControllerWithIdentifier:@"addLiftingVC"];
        navigationController.viewControllers = @[alvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
        
    }else if ([strMenuItem isEqualToString:@"Lifting History"]){
        
//        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] isEqualToString:@"dealer"]) {
//            DealerLiftingHistoryVC *dlhvc = [self.storyboard instantiateViewControllerWithIdentifier:@"dealerLiftingHistoryVC"];
//            navigationController.viewControllers = @[dlhvc];
//            self.frostedViewController.contentViewController = navigationController;
//            [self.frostedViewController hideMenuViewController];
//        }else{
//            LiftingHistoryViewController *lhvc = [self.storyboard instantiateViewControllerWithIdentifier:@"liftingHistoryVC"];
//            navigationController.viewControllers = @[lhvc];
//            self.frostedViewController.contentViewController = navigationController;
//            [self.frostedViewController hideMenuViewController];
//        }
        
        if (checkUserType(kDealer) == true) {
            DealerLiftingHistoryVC *dlhvc = [self.storyboard instantiateViewControllerWithIdentifier:@"dealerLiftingHistoryVC"];
            navigationController.viewControllers = @[dlhvc];
            self.frostedViewController.contentViewController = navigationController;
            [self.frostedViewController hideMenuViewController];
        }else{
            LiftingHistoryViewController *lhvc = [self.storyboard instantiateViewControllerWithIdentifier:@"liftingHistoryVC"];
            navigationController.viewControllers = @[lhvc];
            self.frostedViewController.contentViewController = navigationController;
            [self.frostedViewController hideMenuViewController];
        }
        
    }else if ([strMenuItem isEqualToString:@"Logout"]){
        
        NSString *strUrl = [NSString stringWithFormat:@"http://starsaathi.com/SAP/acedns_star_clear_allocation_by_id.php?the_id=%@",[[NSUserDefaults standardUserDefaults]valueForKey:@"emp_code"]];
        
        //http://starsaathi.com/SAP/acedns_star_clear_allocation_by_id.php?the_id=E0594
        
        [XMLParser callServiceWithPostData:strUrl withParam:nil success:^(NSData *data){
            NSError *jsonParserError;
            NSDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:data
                                                                     options:NSJSONReadingMutableLeaves error:&jsonParserError];
            if ([[jsonData valueForKey:@"process_status"] isEqualToString:@"YES"]) {
                
                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                [defaults setValue:nil      forKey:@"dealer_id"];
                [defaults setValue:nil      forKey:@"emp_code"];
                [defaults setValue:nil      forKey:@"emp_name"];
                [defaults setValue:nil      forKey:@"phone_number"];
                [defaults setValue:nil      forKey:@"selected_cust_code"];
                [defaults setValue:nil      forKey:@"selected_cust_name"];
                [defaults setBool:NO        forKey:@"datadownloaded"];
                [defaults setBool:NO        forKey:@"tablestructure"];
                [defaults setBool:nil       forKey:@"kServeyFormSubmitted"];
                [defaults synchronize];
                
                BOOL success;
                NSError *error;
                
                NSFileManager *fileManager = [NSFileManager defaultManager];
                
                NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
                NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"StarSaathi.db"];
                
                success = [fileManager fileExistsAtPath:filePath];
                if (success) {
                    success = [fileManager removeItemAtPath:filePath error:&error];
                }
                
                if (success) {
                    SplashViewController *svc = [self.storyboard instantiateViewControllerWithIdentifier:@"splashViewController"];
                    navigationController.viewControllers = @[svc];
                    self.frostedViewController.contentViewController = navigationController;
                    [self.frostedViewController hideMenuViewController];
                }
            }else{
                UDShowToastAlertWithTitle([jsonData safeValueeForKey:@"process_message"], 2);
            }
            
        } failed:^(NSString *strErrMsg){
            UDShowToastAlertWithTitle(strErrMsg, 2);
        }];
        
    }else if ([strMenuItem isEqualToString:@"Dealer Visit"]){
        DealerVisitListVC *dvlvc = [self.storyboard instantiateViewControllerWithIdentifier:@"dealerVisitListVC"];
        navigationController.viewControllers = @[dvlvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
    }else if ([strMenuItem isEqualToString:@"Consumer Lottery Scheme"]){
        ConsumerLotterySchemeVC *clsvc = [self.storyboard instantiateViewControllerWithIdentifier:@"conLotterySchemeVC"];
        navigationController.viewControllers = @[clsvc];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
    }
    
}

#pragma mark - MFMailComposeViewController Delegate

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            AppLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            AppLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            AppLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            AppLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
    // Close the Mail Interface
    [self dismissViewControllerAnimated:YES completion:NULL];
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    //imageData = UIImageJPEGRepresentation(chosenImage, 0.5); //JPEG conversion
    imageData = UIImagePNGRepresentation(chosenImage);
    imageView.image = chosenImage;
    [picker dismissViewControllerAnimated:YES completion:NULL];
    [self uploadProfilePic];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

#pragma mark - Helper Method

-(void)uploadProfilePic {
    if (APP_DELEGATE.isServerReachable) {
        
        [SVProgressHUD showWithStatus:@"Uploading..."];
        
        
        
        NSMutableDictionary *dictProfile = [[NSMutableDictionary alloc]init];
        [dictProfile setValue:APP_CONSTANTS.strCustCode forKey:@"the_id"];
        [dictProfile setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_type"] forKey:@"user_type"];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer]; // only needed if the server is not returning JSON; if web service returns JSON, remove this line
        
        [manager POST:@"http://starsaathi.com/SAP/acedns_update_profile_image.php" parameters:dictProfile constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            NSError *error;
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictProfile options:0 error:&error];
            NSAssert(jsonData, @"Failure building JSON: %@", error);
            
            
            NSDictionary *jsonHeaders = @{@"Content-Disposition" : @"form-data; name=\"json\"",
                                          @"Content-Type"        : @"application/json"};
            [formData appendPartWithHeaders:jsonHeaders body:jsonData];
            
            if (self->imageData) {
                [formData appendPartWithFileData:self->imageData name:@"profile_image"
                                        fileName:@"image.png"
                                        mimeType:@"image/png"];
            }
        } progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
            
            [SVProgressHUD dismiss];
            AppLog(@"Response: %@", responseObject);
            NSError* error;
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                 options:kNilOptions
                                                                   error:&error];
            
            AppLog(@"JSON : %@",json);
            
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setObject:json[@"the_profile_image_url"] forKey:@"profile_image"];
            [defaults synchronize];
            
            UDShowToastAlertWithTitle(json[@"process_message"], 2);
            
            
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            AppLog(@"Error: %@", error);
            [SVProgressHUD dismiss];
            UDShowToastAlertWithTitle(error.localizedDescription, 2);
        }];
    }else{
        UDShowToastAlertWithTitle(@"Cannot connect to the server - please check your Internet connection and try again.", 2);
    }
}

@end
