//
//  AppDelegate.h
//  StarCementDealer
//
//  Created by Coral  on 30/05/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MBLocationManager.h>
#import <UserNotifications/UserNotifications.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,UNUserNotificationCenterDelegate>

@property (strong, nonatomic) UIWindow          *window;
@property (assign, nonatomic) BOOL              isServerReachable;
@property (nonatomic, strong) MBLocationManager *locationManageger;
@property (strong, nonatomic) NSString          *strDeviceToken;
@property (strong, nonatomic) NSString          *strServerAppVersion;
@property (strong, nonatomic) NSString          *strDeviceAppVersion;
@property (strong, nonatomic) NSString          *strBranchWisePGRollOut;
@property (strong, nonatomic) NSString          *strDateForNewOrderEnq;


@end

