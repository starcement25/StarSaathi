//
//  main.m
//  StarCementDealer
//
//  Created by Coral  on 30/05/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
