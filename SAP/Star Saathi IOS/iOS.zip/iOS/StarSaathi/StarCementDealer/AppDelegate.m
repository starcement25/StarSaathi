//
//  AppDelegate.m
//  StarCementDealer
//
//  Created by Coral  on 30/05/18.
//  Copyright © 2018 Coral . All rights reserved.
//

#import "AppDelegate.h"
#import "Reachability.h"
#import <SVProgressHUD.h>
#import <AFNetworking.h>


#define SYSTEM_VERSION_GRATERTHAN_OR_EQUALTO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

@interface AppDelegate ()
@property (strong, nonatomic)  Reachability *serverReachability;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
   
//    // Example input string
//    NSString *inputString = @"17th Jul 2024 08:51 PM";
//    
//    // Define the substrings to be replaced and their replacements
//    NSDictionary *replacements = @{
//        @"st": @"",
//        @"nd": @"",
//        @"rd": @"",
//        @"th": @""
//    };
//    
//    // Iterate over the dictionary and replace occurrences
//    for (NSString *key in replacements) {
//        NSString *replacement = replacements[key];
//        inputString = [inputString stringByReplacingOccurrencesOfString:key withString:replacement];
//    }
//    
//    // Output the resulting string
//    NSLog(@"%@", inputString);
//    
//    
//    APP_CONSTANTS.dateFormater.dateFormat = @"dd MMM yyyy hh:mm a";
//    NSDate *date = [APP_CONSTANTS.dateFormater dateFromString:inputString];
//    APP_CONSTANTS.dateFormater.dateFormat = @"yyyy-MM-dd HH:mm:ss"; //2024-07-06 12:52:32
//    NSString *strDate = [APP_CONSTANTS.dateFormater stringFromDate:date];
    
    
    
    
    NSLog(@"--##%@",[[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject]);
    self.locationManageger = [MBLocationManager sharedManager];
    [self.locationManageger startLocationUpdates:kMBLocationManagerModeStandardWhenInUse distanceFilter:10 accuracy:kCLLocationAccuracyNearestTenMeters];
    
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
    [self configureReachability];
    [self checkDeviceValidation];
    //[self registeredForDeviceToken];
    [self registerForRemoteNotification];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    
    self.strDeviceAppVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    
    float fltAppVersion = [self.strDeviceAppVersion floatValue];
    float fltServerVersion = [self.strServerAppVersion floatValue];
    
    if (fltServerVersion > fltAppVersion) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            UIAlertController *alertUpdate = [UIAlertController alertControllerWithTitle:@"Star Saathi" message:@"Update Application" preferredStyle:UIAlertControllerStyleAlert];
            [alertUpdate addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                NSString *strUrl = [NSString stringWithFormat:@"https://itunes.apple.com/in/app/qoie/id%@?mt=8",@"1435155289"];
                //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:simple]];
                UIApplication *application = [UIApplication sharedApplication];
                [application openURL:[NSURL URLWithString:strUrl] options:@{} completionHandler:nil];
            }]];
            [self.window.rootViewController presentViewController:alertUpdate animated:YES completion:nil];
            
        });
    }
    
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark- Reachability
#pragma mark-
-(void)configureReachability
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kReachabilityChangedNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:
     @selector(reachabilityChanged:) name: kReachabilityChangedNotification object: nil];
    self.serverReachability = [Reachability reachabilityForInternetConnection];
    [self.serverReachability startNotifier];
    [self updateInterfaceWithReachability:self.serverReachability];
}

- (void)reachabilityChanged:(NSNotification*)note
{
    Reachability* curReach = [note object];
    NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
    [self updateInterfaceWithReachability:curReach];
}

- (void)updateInterfaceWithReachability:(Reachability*)curReach
{
    NetworkStatus netStatus = [curReach currentReachabilityStatus];
    switch (netStatus)
    {
        case NotReachable:			self.isServerReachable = NO;        break;
        case ReachableViaWWAN:
        case ReachableViaWiFi:      self.isServerReachable = YES;       break;
    }
}

#pragma mark - Device Bounds
-(void)checkDeviceValidation
{
    APP_CONSTANTS.fltAppWidth           = ([[UIScreen mainScreen]bounds]).size.width;
    APP_CONSTANTS.fltAppHeight          = ([[UIScreen mainScreen]bounds]).size.height;
    APP_CONSTANTS.fltExtraWidth         = (([[UIScreen mainScreen]bounds]).size.width-320);
    APP_CONSTANTS.fltExtraHeight        = (([[UIScreen mainScreen]bounds]).size.height-568);
    
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        if(CGSizeEqualToSize([[UIScreen mainScreen]bounds].size, CGSizeMake(320, 568)))
            APP_CONSTANTS.deviceType    = deviceTypeiPhone5;
        else if(CGSizeEqualToSize([[UIScreen mainScreen]bounds].size, CGSizeMake(375, 667)))
            APP_CONSTANTS.deviceType    = deviceTypeiPhone6;
        else if(CGSizeEqualToSize([[UIScreen mainScreen]bounds].size, CGSizeMake(414, 736)))
            APP_CONSTANTS.deviceType    = deviceTypeiPhone6Plus;
    }
    else
        APP_CONSTANTS.deviceType         = deviceTypeiPad;
}



#pragma mark - Remote Notification Delegate // <= iOS 9.x

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings {
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)_deviceToken {
    // Get a hex string from the device token with no spaces or < >
    //    NSString *deviceToken = [[NSString alloc] init];
    self.strDeviceToken = [self stringFromDeviceToken:_deviceToken];
    AppLog(@"---->DeviceToken : %@",self.strDeviceToken);
    [[NSUserDefaults standardUserDefaults] setObject:self.strDeviceToken forKey:kDeviceToken];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
}

-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"Push Notification Information : %@",userInfo);
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    AppLog(@"Device register error :: %@",error.debugDescription);
    [[NSUserDefaults standardUserDefaults] setObject:@"a3d755ab00a53e50d922303403546d2edc16cad5b3d9357f669f44cf97460754" forKey:kDeviceToken];
    self.strDeviceToken = [[NSUserDefaults standardUserDefaults]objectForKey:kDeviceToken];
}

#pragma mark - UNUserNotificationCenter Delegate // >= iOS 10

- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions options))completionHandler{
    
    NSLog(@"User Info = %@",notification.request.content.userInfo);
    
    completionHandler(UNNotificationPresentationOptionAlert | UNNotificationPresentationOptionBadge | UNNotificationPresentationOptionSound);
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void(^)())completionHandler{
    
    NSLog(@"User Info = %@",response.notification.request.content.userInfo);
    completionHandler();
}

#pragma mark - Class Methods

/**
 Notification Registration
 */
- (void)registerForRemoteNotification {
    
    self.strDeviceToken = [[NSUserDefaults standardUserDefaults]objectForKey:kDeviceToken];
    
    if(SYSTEM_VERSION_GRATERTHAN_OR_EQUALTO(@"10.0")) {
        UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
        center.delegate = self;
        [center requestAuthorizationWithOptions:(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error){
            if( !error ){
                dispatch_async(dispatch_get_main_queue(), ^(void){
                    //Run UI Updates
                    [[UIApplication sharedApplication] registerForRemoteNotifications];
                });
            }
        }];
    }
    else {
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
}

- (NSString *)stringFromDeviceToken:(NSData *)deviceToken {
    NSUInteger length = deviceToken.length;
    if (length == 0) {
        return nil;
    }
    const unsigned char *buffer = deviceToken.bytes;
    NSMutableString *hexString  = [NSMutableString stringWithCapacity:(length * 2)];
    for (int i = 0; i < length; ++i) {
        [hexString appendFormat:@"%02x", buffer[i]];
    }
    return [hexString copy];
}

@end
