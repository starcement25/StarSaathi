//
//  BaseJSONParser.m
//  EoKolkata
//
//  Created by Coral  on 04/11/16.
//  Copyright © 2016 Coral . All rights reserved.
//

#import "BaseJSONParser.h"

@implementation BaseJSONParser



+(void)baseServiceWithPostData:(NSString *)strUrl withParam:(NSDictionary *)dictParam
                       success:(void(^)(NSDictionary *dictParser))blockSuccess failed:(void(^)(NSString *strErrorMsg))blockError
{
    NSString* encodedUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:
                            NSUTF8StringEncoding];
    AppLog(@"Request of %@ service is::%@",encodedUrl, [BaseJSONParser stringFromDict:dictParam]);
    AFHTTPSessionManager *operationManager = [AFHTTPSessionManager manager];
    operationManager.requestSerializer                  = [AFHTTPRequestSerializer serializer];
    operationManager.requestSerializer.timeoutInterval  = 30;
    operationManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    [operationManager POST:encodedUrl parameters:dictParam?dictParam:@"" progress:^(NSProgress *progress){
        
    }success:^(NSURLSessionDataTask *task , id responseObject){
        AppLog(@"Response of %@ service is :: %@",encodedUrl, [[NSString alloc] initWithData:responseObject encoding:NSASCIIStringEncoding]);
        [BaseJSONParser handleResponseData:responseObject success:^(NSDictionary *dictParser){
            blockSuccess(dictParser);
        }failed:^(NSString *strErrorMsg){
            blockError(strErrorMsg);
        }];
    }failure:^(NSURLSessionDataTask *task , NSError *error){
        AppLog(@"Base error is ::%@",error.localizedDescription);
        blockError(error.localizedDescription);
    }];
}

+(void)handleResponseData:(NSData *)resposneData success:
(ParserSuccess)blockSuccess failed:(ParserError)blockError
{
    NSError *jsonParserError;
    NSDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:resposneData
                                                             options:NSJSONReadingMutableLeaves error:&jsonParserError];
    if (jsonParserError)
        blockError(kErrorOccured);
    else
        blockSuccess(jsonData);
}



+(NSString *)jsonsStringFromDict:(id)dictionaryOrArrayToOutput
{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictionaryOrArrayToOutput
                                                       options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString = @"";
    if (!jsonData)
        AppLog(@"Got an error: %@", error);
    else
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonString;
}

+(NSString *)stringFromDict:(NSDictionary *)dict
{
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    [dict enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        [arr addObject:[NSString stringWithFormat:@"%@=%@", key, obj]];
    }];
    return [arr componentsJoinedByString:@"&"];
}

@end
